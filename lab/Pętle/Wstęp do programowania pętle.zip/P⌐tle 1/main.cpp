#include <iostream>

using namespace std;

int main()
{

    for(int i=1; i < 100; i=i+2)
    {
        cout << i << endl;
    }
    return 0;
}
//program wpisuj�cy liczby nieparzyste
