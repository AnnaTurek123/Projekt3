#include <iostream>

using namespace std;


int main()
{
    for(int a=0; a <= 255; a++ )
    {
        cout << a << " : " << char(a) << endl;
    }
    return 0;
}

//program wy�wietlania znak�w z kodu Ascii
