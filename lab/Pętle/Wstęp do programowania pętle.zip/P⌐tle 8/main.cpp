#include <iostream>

using namespace std;

int main()
{
    int n; int m;
    cout << "Podaj n" << endl;

    while (n > 0)
    {
        cin >> n;
    }


    return 0;
}
